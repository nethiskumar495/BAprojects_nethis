-- Determine the distribution of orders by hour of the day..
use pizzahut;
Select hour(order_time) as hourly_orders, count(Order_id) as total_orders
from orders
group by hourly_orders order by total_orders desc ;