-- Group the orders by date and calculate the average number of pizzas ordered per day.
use pizzahut;

select round(avg(quantity),0) from
(select orders.Order_date, sum(orders_details.Quantity) as quantity
from orders join orders_details 
on orders.Order_id=orders_details.Order_id
group by orders.Order_date) as Order_Quantity;
