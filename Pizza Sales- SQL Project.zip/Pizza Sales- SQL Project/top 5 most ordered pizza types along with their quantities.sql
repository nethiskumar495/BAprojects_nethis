-- List the top 5 most ordered pizza types along with their quantities.
use pizzahut;
SELECT 
    pizza_types.name,
    SUM(Orders_details.Quantity) AS total_quantity
FROM
    pizza_types
        JOIN
    pizzas ON pizza_types.pizza_type_id = pizzas.pizza_type_id
        JOIN
    orders_details ON orders_details.Pizza_id = pizzas.pizza_id
GROUP BY pizza_types.name
ORDER BY total_quantity DESC
LIMIT 5;
