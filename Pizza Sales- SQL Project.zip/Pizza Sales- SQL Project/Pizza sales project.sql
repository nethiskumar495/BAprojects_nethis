CREATE DATABASE pizzahut;
use pizzahut;
CREATE TABLE Orders(
Order_id int not null,
Order_date date not null,
Order_time time not null,
Primary key(Order_id)
);

CREATE TABLE Orders_details(
Order_details_id int not null,
Order_id int not null,
Pizza_id text not null,
Quantity int not null,
Primary key(Order_details_id)
);