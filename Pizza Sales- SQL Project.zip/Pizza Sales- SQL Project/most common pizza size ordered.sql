-- Identify the most common pizza size ordered.

SELECT 
    quantity, COUNT(order_id)
FROM
    orders_details
GROUP BY quantity;

SELECT 
    pizzas.size,
    COUNT(orders_details.order_details_id) AS order_count
FROM
    pizzas
        JOIN
    orders_details ON pizzas.pizza_id = orders_details.Pizza_id
GROUP BY size
ORDER BY order_count DESC;
